import edu.princeton.cs.algs4.Picture;
import edu.princeton.cs.algs4.StdOut;

import java.awt.*;

public class SeamCarver {

    private final Picture p;
    private double[][] energies;

    // create a seam carver object based on the given picture
    public SeamCarver(Picture picture) {
        if (picture.width() < 0 || picture.height() < 0) throw new IllegalArgumentException();

        this.p = new Picture(picture);
        this.energies = new double[this.p.height()][this.p.width()];

        for (int x = 0; x < this.p.width(); x++) {
            for (int y = 0; y < this.p.height(); y++) {
                this.energies[y][x] = this.energy(x, y);
            }
        }
        StdOut.println(1);

    }

    // current picture
    public Picture picture() {
        return this.p;
    }

    // width of current picture
    public int width() {
        return this.p.width();
    }

    // height of current picture
    public int height() {
        return this.p.height();
    }

    // energy of pixel at column x and row y
    public double energy(int x, int y) {
        if (x == 0 || this.width() - 1 == x) return 1000;
        if (y == 0 || this.height() - 1 == y) return 1000;

        return Math.sqrt(this.squareGradientX(x, y) + this.squareGradientY(x, y));
    }

    private double squareGradientY(int x, int y) {
        Color c1 = this.p.get(x, y - 1);
        Color c2 = this.p.get(x, y + 1);

        return this.calcColors(c1, c2);
    }

    private double squareGradientX(int x, int y) {
        Color c1 = this.p.get(x - 1, y);
        Color c2 = this.p.get(x + 1, y);
        return this.calcColors(c1, c2);
    }

    private double calcColors(Color c1, Color c2) {
        double r = c2.getRed() - c1.getRed();
        double g = c2.getGreen() - c1.getGreen();
        double b = c2.getBlue() - c1.getBlue();

        return r * r + g * g + b * b;
    }

    // sequence of indices for horizontal seam
    public int[] findHorizontalSeam() {
        int w = this.width();
        int h = this.height();
        double[][] dist = new double[h][w];
        int[][] edgeTo = new int[h][w];

        for (int x = 1; x < w - 1; x++) {
            Integer prev = null;
            for (int y = 0; y < h - 1; y++) {

                double d = 0;
                if (prev == null) {
                    d = this.energies[y][x];
                } else {
                    d = dist[y][prev];
                }


                int yNext = y + 1;

                // middle point
                double xNextMin = this.energies[yNext][x] + d;
                int xNextMinIndex = x;
                if (dist[yNext][x] > xNextMin || dist[yNext][x] == 0) {
                    dist[yNext][x] = xNextMin;
                    edgeTo[yNext][x] = x;
                }

                // left point
                if (x - 1 > 0) {
                    int xNextLeft = x - 1;
                    double left = this.energies[yNext][xNextLeft] + d;
                    if (dist[yNext][xNextLeft] > left || dist[yNext][xNextLeft] == 0) {
                        dist[yNext][xNextLeft] = left;
                        edgeTo[yNext][xNextLeft] = xNextLeft;
                    }

                    if (left < xNextMin) {
                        xNextMin = left;
                        xNextMinIndex = xNextLeft;
                    }
                }

                // right point
                if (x + 1 < w) {
                    int xNextRight = x + 1;
                    double right = this.energies[yNext][xNextRight] + d;

                    if (dist[yNext][xNextMinIndex] > right || dist[yNext][xNextMinIndex] == 0) {
                        dist[yNext][xNextMinIndex] = right;
                        edgeTo[yNext][xNextMinIndex] = xNextRight;
                    }

                    if (right < xNextMin) {
                        xNextMin = right;
                        xNextMinIndex = xNextRight;
                    }
                }

                double closest = dist[yNext][xNextMinIndex];
                if (dist[yNext][xNextMinIndex] == 0.0) {
                    dist[yNext][xNextMinIndex] = xNextMin ;
                    edgeTo[yNext][xNextMinIndex] = x;
                    prev = xNextMinIndex;
                } else {
                    if (closest >= xNextMin) {
                        dist[yNext][xNextMinIndex] = xNextMin;
                        edgeTo[yNext][xNextMinIndex] = x;
                        prev = xNextMinIndex;
                    }
                }
            }
        }

        return null;
    }

    // sequence of indices for vertical seam
    public int[] findVerticalSeam() {
        return null;
    }

    // remove horizontal seam from current picture
    public void removeHorizontalSeam(int[] seam) {
        if (seam == null) throw new IllegalArgumentException();
    }

    // remove vertical seam from current picture
    public void removeVerticalSeam(int[] seam) {
        if (seam == null) throw new IllegalArgumentException();
    }

    //  unit testing (optional)
    public static void main(String[] args) {
    }

}